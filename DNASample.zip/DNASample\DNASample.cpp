#include "stdafx.h"
#include "windows.h"
#include "istream.h"
#include "ostream.h"
#include "ezdnaapi.h"
#include <malloc.h>

int main(int argc, char* argv[])
{
	char *szString;
	double dPoint;

	szString = (char *)malloc(50);

	cout << "Enter point name -> ";
	cin >> szString;

	if (DNAGoodPointFormat(szString))
	{
		if (!DNAGetRTValue(szString,&dPoint))
		{
			cout << "Value is " << dPoint << "\n";
		}
		else
		{
			cout << "No data..." << "\n";
		}
	}
	else
	{
		cout << "Bad datapoint..." << "\n";
	}

	free(szString);

	return 0;
}

